from flask import Flask, render_template, request, json
from flask_mysqldb import MySQL
import requests

app = Flask(__name__)

app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'patient_data'
app.config['MYSQL_HOST'] = 'localhost'


mysql = MySQL(app)


@app.route('/', methods=['GET', 'POST'])
def patient_registration():

    #Getting Api json data
    r = requests.get("http://date.jsontest.com/")
    data = r.text


    #Dealing with user form 
    if request.method == 'POST':
        details = request.form
        firstname = details['fname']
        lastname = details['lname']
        #Submit the base64 code posted by the API
        fprint_code = json.loads(data)['date']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO patient_info(firstname, lastname, fingerprint_code) VALUES (%s, %s, %s)", (firstname, lastname, fprint_code))
        mysql.connection.commit()
        cur.close()
        return 'sucessfully submited'
    #Show The fingerprint image displayed by the API 
    return render_template('registration.html', time=json.loads(data)['time'])


# @app.route('/json')
# def patient_registration():

#     r = requests.get("http://date.jsontest.com/")
#     data = r.text
#     # return data
#     # posts = json.loads(r.text)


#     # for posts in r:
#     #     return posts
#     return render_template('registration.html', date=json.loads(data)['date'])
        

if __name__ == "__main__":
    app.run()



