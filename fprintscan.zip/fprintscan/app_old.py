from flask import Flask, render_template
import requests

app = Flask(__name__, template_folder='templates')


# # method = ['POST']
@app.route('/json')
def patient_registration():

    r = requests.get("https://github.com/typicode/demo/blob/master/db.json")
    data = r.text

    for post in data:
        print(post)
    

if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True)

    # # return render_template('registration.html')
    # value = []
    # if (request.method == 'PUT'):
    #     input = request.get_json()
    #     if (input is None):
    #         return 'Expected JSON, Failed to populate'
    #     try:
    #         if ('WSQImage' in input):
    #             return render_template('registration.html')


# # method = ['GET']
# @app.route('/matching')
# def patient_matching():
#     return 'Hello This where we match'



